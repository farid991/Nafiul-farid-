import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ArrowRight, Download, Instagram, Linkedin, Dribbble, Github } from 'lucide-react';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const buttonsRef = useRef<HTMLDivElement>(null);
  const socialsRef = useRef<HTMLDivElement>(null);
  const decorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Initial states
      gsap.set([titleRef.current, subtitleRef.current, buttonsRef.current, socialsRef.current], {
        opacity: 0,
        y: 30
      });
      gsap.set(imageRef.current, {
        opacity: 0,
        rotateY: 30,
        x: 100
      });
      gsap.set(decorRef.current, {
        opacity: 0,
        scale: 0.8
      });

      // Animation timeline
      const tl = gsap.timeline({ delay: 0.3 });

      tl.to(decorRef.current, {
        opacity: 1,
        scale: 1,
        duration: 1.2,
        ease: 'expo.out'
      })
      .to(imageRef.current, {
        opacity: 1,
        rotateY: 0,
        x: 0,
        duration: 1,
        ease: 'expo.out'
      }, '-=0.8')
      .to(titleRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: 'expo.out'
      }, '-=0.6')
      .to(subtitleRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.6,
        ease: 'smooth'
      }, '-=0.4')
      .to(buttonsRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.5,
        ease: 'back.out(1.7)'
      }, '-=0.3')
      .to(socialsRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.6,
        ease: 'expo.out'
      }, '-=0.2');

      // Floating animation for image
      gsap.to(imageRef.current, {
        y: -15,
        duration: 3,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut'
      });

      // Decorative shapes rotation
      gsap.to('.decor-shape', {
        rotation: 360,
        duration: 20,
        repeat: -1,
        ease: 'none'
      });

    }, heroRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      ref={heroRef}
      id="beranda"
      className="relative min-h-screen w-full flex items-center overflow-hidden bg-white"
    >
      {/* Decorative Background Elements */}
      <div ref={decorRef} className="absolute inset-0 pointer-events-none">
        {/* Gradient blob */}
        <div className="absolute top-20 right-20 w-[500px] h-[500px] bg-gradient-to-br from-[#ffed28]/20 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-[400px] h-[400px] bg-gradient-to-tr from-[#ffed28]/10 to-transparent rounded-full blur-3xl" />
        
        {/* Floating shapes */}
        <div className="decor-shape absolute top-32 left-[15%] w-16 h-16 border-2 border-[#ffed28] rounded-lg opacity-60" />
        <div className="decor-shape absolute bottom-40 right-[20%] w-12 h-12 bg-[#ffed28]/30 rounded-full" />
        <div className="decor-shape absolute top-[40%] right-[10%] w-8 h-8 border border-black/20 rotate-45" />
        <div className="decor-shape absolute bottom-32 left-[10%] w-6 h-6 bg-black/10 rounded-full" />
        
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `
              linear-gradient(to right, #000 1px, transparent 1px),
              linear-gradient(to bottom, #000 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px'
          }}
        />
      </div>

      <div className="relative z-10 w-full px-6 sm:px-8 lg:px-16 xl:px-24 py-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center max-w-7xl mx-auto">
          {/* Content Column */}
          <div className="order-2 lg:order-1 space-y-8">
            {/* Label */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#f8f8f8] rounded-full">
              <span className="w-2 h-2 bg-[#ffed28] rounded-full animate-pulse" />
              <span className="text-sm font-medium text-gray-600">Selamat Datang di Portfolio Saya</span>
            </div>

            {/* Main Title */}
            <h1 
              ref={titleRef}
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight"
            >
              <span className="block text-gray-500 text-2xl sm:text-3xl lg:text-4xl font-medium mb-2">
                Halo, Saya
              </span>
              <span className="block">
                Nafi'ul farid
              </span>
              <span className="block mt-2">
                <span className="text-gradient">Creative</span> Designer
              </span>
              <span className="block text-gray-400">
                & Developer
              </span>
            </h1>

            {/* Subtitle */}
            <p 
              ref={subtitleRef}
              className="text-lg sm:text-xl text-gray-600 max-w-lg leading-relaxed"
            >
              Saya menciptakan pengalaman digital yang menarik dan fungsional. 
              Dengan kombinasi desain kreatif dan teknologi modern.
            </p>

            {/* CTA Buttons */}
            <div ref={buttonsRef} className="flex flex-wrap gap-4">
              <button 
                onClick={() => scrollToSection('proyek')}
                className="btn-primary group"
              >
                Lihat Karya Saya
                <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </button>
              <button 
                onClick={() => scrollToSection('kontak')}
                className="btn-secondary"
              >
                Hubungi Saya
              </button>
            </div>

            {/* Social Links */}
            <div ref={socialsRef} className="flex items-center gap-4 pt-4">
              <span className="text-sm text-gray-500">Ikuti saya:</span>
              <div className="flex gap-3">
                {[
                  { icon: Instagram, href: '#' },
                  { icon: Linkedin, href: '#' },
                  { icon: Dribbble, href: '#' },
                  { icon: Github, href: '#' }
                ].map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    className="w-10 h-10 flex items-center justify-center rounded-full bg-[#f8f8f8] text-gray-600 hover:bg-[#ffed28] hover:text-black transition-all duration-300 hover:scale-110 hover:rotate-12"
                  >
                    <social.icon className="w-5 h-5" />
                  </a>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-6 border-t border-gray-200">
              {[
                { value: '5+', label: 'Tahun Pengalaman' },
                { value: '50+', label: 'Proyek Selesai' },
                { value: '30+', label: 'Klien Puas' }
              ].map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-2xl sm:text-3xl font-bold text-black">{stat.value}</div>
                  <div className="text-sm text-gray-500">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Image Column */}
          <div className="order-1 lg:order-2 flex justify-center lg:justify-end perspective-1200">
            <div 
              ref={imageRef}
              className="relative preserve-3d"
            >
              {/* Main Image Container */}
              <div className="relative w-[280px] sm:w-[350px] lg:w-[400px] xl:w-[450px]">
                {/* Glow effect */}
                <div className="absolute inset-0 bg-[#ffed28]/30 rounded-[2rem] blur-3xl scale-90 translate-y-8" />
                
                {/* Image frame */}
                <div className="relative bg-gradient-to-br from-[#ffed28]/20 to-transparent p-2 rounded-[2rem]">
                  <div className="relative overflow-hidden rounded-[1.5rem] bg-[#f8f8f8]">
                    <img
                      src="/hero-profile.jpg"
                      alt="Nafi'ul farid"
                      className="w-full h-auto object-cover"
                    />
                    
                    {/* Overlay gradient */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent" />
                  </div>
                </div>

                {/* Floating badge */}
                <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-xl p-4 floating">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-[#ffed28] rounded-xl flex items-center justify-center">
                      <Download className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold">CV Tersedia</div>
                      <div className="text-xs text-gray-500">Unduh Sekarang</div>
                    </div>
                  </div>
                </div>

                {/* Experience badge */}
                <div className="absolute -top-4 -right-4 bg-black text-white rounded-2xl shadow-xl px-4 py-3 floating" style={{ animationDelay: '1s' }}>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#ffed28]">5+</div>
                    <div className="text-xs">Tahun</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
