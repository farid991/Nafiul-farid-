import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Award, Briefcase, Users, Download } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const About = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const [counters, setCounters] = useState({ years: 0, projects: 0, clients: 0 });

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Image animation
      gsap.fromTo(imageRef.current,
        { opacity: 0, x: -80, rotateY: -15 },
        {
          opacity: 1,
          x: 0,
          rotateY: 0,
          duration: 1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Content animation
      const contentElements = contentRef.current?.querySelectorAll('.reveal-item');
      if (contentElements) {
        gsap.fromTo(contentElements,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 60%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Stats counter animation
      ScrollTrigger.create({
        trigger: statsRef.current,
        start: 'top 80%',
        onEnter: () => {
          // Animate counters
          gsap.to({}, {
            duration: 2,
            ease: 'expo.out',
            onUpdate: function() {
              const progress = this.progress();
              setCounters({
                years: Math.round(5 * progress),
                projects: Math.round(50 * progress),
                clients: Math.round(30 * progress)
              });
            }
          });
        },
        once: true
      });

      // Stats cards animation
      const statCards = statsRef.current?.querySelectorAll('.stat-card');
      if (statCards) {
        gsap.fromTo(statCards,
          { opacity: 0, y: 30, scale: 0.9 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.5,
            stagger: 0.15,
            ease: 'back.out(1.7)',
            scrollTrigger: {
              trigger: statsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="tentang"
      className="relative w-full py-24 lg:py-32 bg-white overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-[#f8f8f8] to-transparent opacity-50" />
      
      <div className="relative z-10 w-full px-6 sm:px-8 lg:px-16 xl:px-24">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            
            {/* Image Column */}
            <div ref={imageRef} className="relative perspective-1200">
              <div className="relative preserve-3d">
                {/* Main image */}
                <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                  <img
                    src="/hero-profile.jpg"
                    alt="About Me"
                    className="w-full h-auto object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </div>
                
                {/* Decorative frame */}
                <div className="absolute -top-4 -left-4 w-full h-full border-2 border-[#ffed28] rounded-3xl -z-10" />
                
                {/* Floating element */}
                <div className="absolute -bottom-6 -right-6 bg-[#ffed28] rounded-2xl p-4 shadow-xl">
                  <Award className="w-8 h-8" />
                </div>
              </div>
            </div>

            {/* Content Column */}
            <div ref={contentRef} className="space-y-6">
              {/* Section Label */}
              <div className="reveal-item">
                <span className="section-label">Tentang Saya</span>
              </div>

              {/* Headline */}
              <h2 className="reveal-item text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight">
                Perjalanan <span className="text-gradient">Kreatif</span> Saya
              </h2>

              {/* Description */}
              <div className="reveal-item space-y-4 text-gray-600 leading-relaxed">
                <p>
                  Saya adalah seorang Creative Designer dan Full-Stack Developer dengan passion 
                  dalam menciptakan pengalaman digital yang tidak hanya indah secara visual, 
                  tetapi juga fungsional dan user-friendly.
                </p>
                <p>
                  Dengan pengalaman lebih dari 5 tahun di industri ini, saya telah membantu 
                  berbagai klien dari startup hingga perusahaan besar untuk mewujudkan visi 
                  digital mereka. Saya percaya bahwa desain yang baik adalah desain yang 
                  mampu menyelesaikan masalah dan memberikan nilai tambah.
                </p>
              </div>

              {/* Skills tags */}
              <div className="reveal-item flex flex-wrap gap-2">
                {['UI/UX Design', 'Web Development', 'Mobile App', 'Branding', 'Motion Design'].map((skill, index) => (
                  <span 
                    key={index}
                    className="px-4 py-2 bg-[#f8f8f8] rounded-full text-sm font-medium text-gray-700 hover:bg-[#ffed28] hover:text-black transition-colors duration-300"
                  >
                    {skill}
                  </span>
                ))}
              </div>

              {/* CTA Button */}
              <div className="reveal-item pt-4">
                <button className="btn-secondary group">
                  <Download className="w-5 h-5" />
                  Unduh CV Saya
                </button>
              </div>
            </div>
          </div>

          {/* Stats Section */}
          <div ref={statsRef} className="mt-24 grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { 
                icon: Briefcase, 
                value: counters.years, 
                suffix: '+', 
                label: 'Tahun Pengalaman',
                color: 'bg-blue-50'
              },
              { 
                icon: Award, 
                value: counters.projects, 
                suffix: '+', 
                label: 'Proyek Selesai',
                color: 'bg-purple-50'
              },
              { 
                icon: Users, 
                value: counters.clients, 
                suffix: '+', 
                label: 'Klien Puas',
                color: 'bg-green-50'
              }
            ].map((stat, index) => (
              <div 
                key={index}
                className="stat-card group relative bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-500 border border-gray-100 hover:-translate-y-2"
              >
                <div className={`w-14 h-14 ${stat.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <stat.icon className="w-7 h-7 text-gray-700" />
                </div>
                <div className="text-4xl lg:text-5xl font-bold mb-2">
                  {stat.value}{stat.suffix}
                </div>
                <div className="text-gray-500">{stat.label}</div>
                
                {/* Hover accent */}
                <div className="absolute bottom-0 left-0 w-full h-1 bg-[#ffed28] scale-x-0 group-hover:scale-x-100 transition-transform duration-500 rounded-b-3xl" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
