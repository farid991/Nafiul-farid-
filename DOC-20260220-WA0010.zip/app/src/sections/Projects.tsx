import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowUpRight, ExternalLink } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Project {
  id: number;
  title: string;
  category: string;
  description: string;
  image: string;
  tags: string[];
  link: string;
}

const projects: Project[] = [
  {
    id: 1,
    title: 'Aplikasi Stream',
    category: 'UI/UX Design',
    description: 'Aplikasi streaming musik dengan antarmuka modern dan pengalaman pengguna yang intuitif.',
    image: '/project-1.jpg',
    tags: ['Figma', 'Prototyping', 'User Research'],
    link: '#'
  },
  {
    id: 2,
    title: 'Sistem Manajemen',
    category: 'Web Design',
    description: 'Dashboard analitik untuk manajemen bisnis dengan visualisasi data yang powerful.',
    image: '/project-2.jpg',
    tags: ['React', 'Dashboard', 'Analytics'],
    link: '#'
  },
  {
    id: 3,
    title: 'Website E-commerce',
    category: 'Web Development',
    description: 'Platform e-commerce dengan fitur lengkap dan pengalaman belanja yang seamless.',
    image: '/project-3.jpg',
    tags: ['Next.js', 'E-commerce', 'Payment'],
    link: '#'
  },
  {
    id: 4,
    title: 'Aplikasi Travel',
    category: 'Mobile Development',
    description: 'Aplikasi pemesanan perjalanan dengan rekomendasi AI dan booking realtime.',
    image: '/project-4.jpg',
    tags: ['React Native', 'AI', 'Booking'],
    link: '#'
  }
];

const Projects = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      const headerItems = headerRef.current?.querySelectorAll('.reveal-item');
      if (headerItems && headerItems.length > 0) {
        gsap.fromTo(headerItems,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Cards animation
      const cards = cardsRef.current?.querySelectorAll('.project-card');
      if (cards && cards.length > 0) {
        gsap.fromTo(cards,
          { opacity: 0, y: 60, rotateX: 10 },
          {
            opacity: 1,
            y: 0,
            rotateX: 0,
            duration: 0.8,
            stagger: 0.15,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="proyek"
      className="relative w-full py-24 lg:py-32 bg-[#f8f8f8] overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-white to-transparent" />
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-white to-transparent" />
      
      <div className="relative z-10 w-full px-6 sm:px-8 lg:px-16 xl:px-24">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div ref={headerRef} className="text-center mb-16">
            <span className="reveal-item section-label inline-block mb-4">Proyek Terbaru</span>
            <h2 className="reveal-item text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Karya yang Telah <span className="text-gradient">Saya Buat</span>
            </h2>
            <p className="reveal-item text-gray-600 max-w-2xl mx-auto text-lg">
              Berikut adalah beberapa proyek terbaik yang telah saya kerjakan. 
              Setiap proyek adalah hasil dari dedikasi dan kreativitas.
            </p>
          </div>

          {/* Projects Grid */}
          <div ref={cardsRef} className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <div
                key={project.id}
                className="project-card group relative bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500"
                onMouseEnter={() => setActiveIndex(index)}
              >
                {/* Image Container */}
                <div className="relative h-64 sm:h-80 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  
                  {/* Category Badge */}
                  <div className="absolute top-4 left-4 px-4 py-2 bg-white/90 backdrop-blur-sm rounded-full text-sm font-medium">
                    {project.category}
                  </div>
                  
                  {/* Hover Content */}
                  <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map((tag, tagIndex) => (
                        <span 
                          key={tagIndex}
                          className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-xs text-white"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    <a 
                      href={project.link}
                      className="inline-flex items-center gap-2 text-white font-medium hover:text-[#ffed28] transition-colors"
                    >
                      Lihat Detail
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-xl font-bold mb-2 group-hover:text-gradient transition-all duration-300">
                        {project.title}
                      </h3>
                      <p className="text-gray-600 text-sm line-clamp-2">
                        {project.description}
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-[#f8f8f8] rounded-full flex items-center justify-center group-hover:bg-[#ffed28] transition-colors duration-300 flex-shrink-0">
                      <ArrowUpRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </div>
                  </div>
                </div>

                {/* Bottom accent line */}
                <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#ffed28] to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
              </div>
            ))}
          </div>

          {/* View All Button */}
          <div className="text-center mt-12">
            <button className="btn-primary group">
              Lihat Semua Proyek
              <ArrowUpRight className="w-5 h-5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>

          {/* Progress Indicator */}
          <div className="flex justify-center gap-2 mt-8">
            {projects.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === activeIndex ? 'w-8 bg-[#ffed28]' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
