import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Instagram, 
  Linkedin, 
  Dribbble, 
  Github,
  ArrowUp,
  Heart
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Footer = () => {
  const footerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const footerItems = contentRef.current?.querySelectorAll('.footer-item');
      if (footerItems && footerItems.length > 0) {
        gsap.fromTo(footerItems,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: footerRef.current,
              start: 'top 90%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }
    }, footerRef);

    return () => ctx.revert();
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navLinks = [
    { label: 'Beranda', href: '#beranda' },
    { label: 'Tentang', href: '#tentang' },
    { label: 'Proyek', href: '#proyek' },
    { label: 'Layanan', href: '#layanan' },
    { label: 'Kontak', href: '#kontak' }
  ];

  const socialLinks = [
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Dribbble, href: '#', label: 'Dribbble' },
    { icon: Github, href: '#', label: 'Github' }
  ];

  return (
    <footer 
      ref={footerRef}
      className="relative w-full bg-black text-white overflow-hidden"
    >
      {/* Top wave decoration */}
      <div className="absolute top-0 left-0 w-full overflow-hidden leading-none">
        <svg 
          className="relative block w-full h-12"
          viewBox="0 0 1200 120" 
          preserveAspectRatio="none"
        >
          <path 
            d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" 
            className="fill-[#f8f8f8]"
          />
        </svg>
      </div>

      <div ref={contentRef} className="relative z-10 w-full px-6 sm:px-8 lg:px-16 xl:px-24 pt-24 pb-8">
        <div className="max-w-7xl mx-auto">
          {/* Main Footer Content */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            {/* Brand Column */}
            <div className="footer-item lg:col-span-2">
              <a href="#beranda" className="inline-block mb-6">
                <span className="text-3xl font-bold">
                  PORT<span className="text-[#ffed28]">FOLIO</span>
                </span>
              </a>
              <p className="text-gray-400 mb-6 max-w-md leading-relaxed">
                Creative Designer & Developer yang berfokus menciptakan 
                pengalaman digital yang menarik, fungsional, dan berdampak.
              </p>
              
              {/* Social Links */}
              <div className="flex gap-3">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    className="w-11 h-11 bg-white/10 rounded-xl flex items-center justify-center hover:bg-[#ffed28] hover:text-black hover:scale-110 hover:rotate-6 transition-all duration-300"
                  >
                    <social.icon className="w-5 h-5" />
                  </a>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div className="footer-item">
              <h4 className="text-lg font-bold mb-6">Menu Cepat</h4>
              <ul className="space-y-3">
                {navLinks.map((link, index) => (
                  <li key={index}>
                    <a 
                      href={link.href}
                      className="text-gray-400 hover:text-[#ffed28] transition-colors duration-300 inline-flex items-center gap-2 group"
                    >
                      <span className="w-0 h-0.5 bg-[#ffed28] group-hover:w-4 transition-all duration-300" />
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Info */}
            <div className="footer-item">
              <h4 className="text-lg font-bold mb-6">Kontak</h4>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <a 
                    href="mailto:hello@andiwijaya.com"
                    className="hover:text-[#ffed28] transition-colors duration-300"
                  >
                    hello@andiwijaya.com
                  </a>
                </li>
                <li>
                  <a 
                    href="tel:+6281234567890"
                    className="hover:text-[#ffed28] transition-colors duration-300"
                  >
                    +62 812 3456 7890
                  </a>
                </li>
                <li>Jakarta, Indonesia</li>
              </ul>
            </div>
          </div>

          {/* Divider */}
          <div className="footer-item border-t border-white/10 pt-8">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              {/* Copyright */}
              <p className="text-gray-400 text-sm flex items-center gap-1">
                © 2024 Portfolio. Made with 
                <Heart className="w-4 h-4 text-red-500 fill-red-500" /> 
                by Nafi'ul farid
              </p>

              {/* Back to Top */}
              <button
                onClick={scrollToTop}
                className="group flex items-center gap-2 text-gray-400 hover:text-[#ffed28] transition-colors duration-300"
              >
                <span className="text-sm">Kembali ke atas</span>
                <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center group-hover:bg-[#ffed28] group-hover:text-black transition-all duration-300">
                  <ArrowUp className="w-5 h-5 group-hover:-translate-y-0.5 transition-transform duration-300" />
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Background decoration */}
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-gradient-to-tl from-[#ffed28]/5 to-transparent rounded-full blur-3xl pointer-events-none" />
    </footer>
  );
};

export default Footer;
