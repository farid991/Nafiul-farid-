import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Palette, Code, Smartphone, Layers, Play, MessageCircle, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Service {
  icon: React.ElementType;
  title: string;
  description: string;
  features: string[];
  color: string;
}

const services: Service[] = [
  {
    icon: Palette,
    title: 'UI/UX Design',
    description: 'Merancang antarmuka yang intuitif dan menarik untuk pengalaman pengguna terbaik.',
    features: ['User Research', 'Wireframing', 'Prototyping', 'Visual Design'],
    color: 'from-purple-500 to-pink-500'
  },
  {
    icon: Code,
    title: 'Web Development',
    description: 'Membangun website responsif dan performant dengan teknologi terkini.',
    features: ['React/Next.js', 'Node.js', 'Database', 'API Integration'],
    color: 'from-blue-500 to-cyan-500'
  },
  {
    icon: Smartphone,
    title: 'Mobile App',
    description: 'Aplikasi mobile native dan cross-platform untuk iOS dan Android.',
    features: ['React Native', 'Flutter', 'iOS', 'Android'],
    color: 'from-green-500 to-emerald-500'
  },
  {
    icon: Layers,
    title: 'Branding',
    description: 'Identitas visual yang kuat dan memorable untuk bisnis Anda.',
    features: ['Logo Design', 'Brand Guidelines', 'Marketing Collateral', 'Visual Identity'],
    color: 'from-orange-500 to-red-500'
  },
  {
    icon: Play,
    title: 'Motion Design',
    description: 'Animasi yang memberikan life pada desain dan meningkatkan engagement.',
    features: ['Micro-interactions', 'Lottie Animation', 'Video Editing', '3D Motion'],
    color: 'from-indigo-500 to-purple-500'
  },
  {
    icon: MessageCircle,
    title: 'Konsultasi',
    description: 'Solusi digital yang tepat untuk kebutuhan bisnis Anda.',
    features: ['Strategy', 'Tech Consulting', 'Product Planning', 'Digital Transformation'],
    color: 'from-teal-500 to-blue-500'
  }
];

const Services = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      const headerItems = headerRef.current?.querySelectorAll('.reveal-item');
      if (headerItems && headerItems.length > 0) {
        gsap.fromTo(headerItems,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Cards animation with stagger
      const cards = cardsRef.current?.querySelectorAll('.service-card');
      if (cards && cards.length > 0) {
        gsap.fromTo(cards,
          { opacity: 0, y: 50, scale: 0.95 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.6,
            stagger: {
              each: 0.1,
              from: 'start'
            },
            ease: 'expo.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="layanan"
      className="relative w-full py-24 lg:py-32 bg-white overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-br from-[#ffed28]/5 to-transparent rounded-full blur-3xl pointer-events-none" />
      
      <div className="relative z-10 w-full px-6 sm:px-8 lg:px-16 xl:px-24">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div ref={headerRef} className="text-center mb-16">
            <span className="reveal-item section-label inline-block mb-4">Layanan</span>
            <h2 className="reveal-item text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Apa yang Bisa Saya <span className="text-gradient">Bantu</span>
            </h2>
            <p className="reveal-item text-gray-600 max-w-2xl mx-auto text-lg">
              Saya menawarkan berbagai layanan untuk membantu Anda mewujudkan 
              visi digital dengan kualitas terbaik.
            </p>
          </div>

          {/* Services Grid */}
          <div ref={cardsRef} className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <div
                key={index}
                className="service-card group relative bg-white rounded-3xl p-8 border border-gray-100 hover:border-transparent shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 overflow-hidden"
              >
                {/* Background gradient on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />
                
                {/* Icon */}
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-[#f8f8f8] rounded-2xl flex items-center justify-center group-hover:bg-[#ffed28] transition-all duration-500 group-hover:scale-110 group-hover:rotate-3">
                    <service.icon className="w-8 h-8 text-gray-700 group-hover:text-black transition-colors duration-300" />
                  </div>
                  {/* Glow effect */}
                  <div className="absolute inset-0 w-16 h-16 bg-[#ffed28]/30 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold mb-3 group-hover:text-gradient transition-all duration-300">
                  {service.title}
                </h3>
                <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Features */}
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li 
                      key={featureIndex}
                      className="flex items-center gap-2 text-sm text-gray-500"
                    >
                      <span className="w-1.5 h-1.5 bg-[#ffed28] rounded-full" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <a 
                  href="#kontak"
                  className="inline-flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-black group/link"
                >
                  Pelajari Lebih Lanjut
                  <ArrowRight className="w-4 h-4 transition-transform group-hover/link:translate-x-1" />
                </a>

                {/* Corner accent */}
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-[#ffed28]/10 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </div>
            ))}
          </div>

          {/* Bottom CTA */}
          <div className="mt-16 text-center">
            <div className="inline-flex flex-col sm:flex-row items-center gap-4 p-6 bg-[#f8f8f8] rounded-3xl">
              <div className="text-center sm:text-left">
                <h4 className="text-lg font-bold mb-1">Punya proyek dalam pikiran?</h4>
                <p className="text-gray-600 text-sm">Mari diskusikan bagaimana saya bisa membantu.</p>
              </div>
              <a href="#kontak" className="btn-primary whitespace-nowrap">
                Mulai Diskusi
                <ArrowRight className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
