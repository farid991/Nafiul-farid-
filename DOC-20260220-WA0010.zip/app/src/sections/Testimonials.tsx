import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote, ChevronLeft, ChevronRight, Star } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Testimonial {
  id: number;
  name: string;
  role: string;
  company: string;
  image: string;
  content: string;
  rating: number;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Budi Santoso',
    role: 'CEO',
    company: 'TechStart',
    image: '/avatar-1.jpg',
    content: 'Kerja sangat profesional dan hasilnya melebihi ekspektasi. Sangat memahami kebutuhan bisnis dan mampu menerjemahkan menjadi desain yang indah dan fungsional. Highly recommended!',
    rating: 5
  },
  {
    id: 2,
    name: 'Anita Wijaya',
    role: 'Founder',
    company: 'CreativeHub',
    image: '/avatar-2.jpg',
    content: 'Sangat memahami kebutuhan dan memberikan solusi kreatif yang luar biasa. Proses kerja yang transparan dan komunikasi yang sangat baik throughout the project.',
    rating: 5
  },
  {
    id: 3,
    name: 'Rudi Hartono',
    role: 'Product Manager',
    company: 'InnovateCo',
    image: '/avatar-3.jpg',
    content: 'Kolaborasi yang sangat menyenangkan dengan hasil yang selalu berkualitas. Attention to detail yang tinggi dan selalu deliver on time. Partner yang sangat reliable.',
    rating: 5
  }
];

const Testimonials = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      const headerItems = headerRef.current?.querySelectorAll('.reveal-item');
      if (headerItems && headerItems.length > 0) {
        gsap.fromTo(headerItems,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Slider animation
      if (sliderRef.current) {
        gsap.fromTo(sliderRef.current,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sliderRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const goToSlide = (index: number) => {
    if (isAnimating || index === currentIndex) return;
    setIsAnimating(true);
    
    gsap.to('.testimonial-card', {
      opacity: 0,
      x: index > currentIndex ? -50 : 50,
      duration: 0.3,
      onComplete: () => {
        setCurrentIndex(index);
        gsap.fromTo('.testimonial-card',
          { opacity: 0, x: index > currentIndex ? 50 : -50 },
          { 
            opacity: 1, 
            x: 0, 
            duration: 0.4,
            ease: 'expo.out',
            onComplete: () => setIsAnimating(false)
          }
        );
      }
    });
  };

  const nextSlide = () => {
    const next = (currentIndex + 1) % testimonials.length;
    goToSlide(next);
  };

  const prevSlide = () => {
    const prev = (currentIndex - 1 + testimonials.length) % testimonials.length;
    goToSlide(prev);
  };

  // Auto-play
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isAnimating) {
        nextSlide();
      }
    }, 6000);

    return () => clearInterval(interval);
  }, [currentIndex, isAnimating]);

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section 
      ref={sectionRef}
      id="testimoni"
      className="relative w-full py-24 lg:py-32 bg-white overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-gradient-to-r from-[#ffed28]/10 to-transparent rounded-full blur-3xl -translate-y-1/2 pointer-events-none" />
      <div className="absolute top-1/2 right-0 w-[400px] h-[400px] bg-gradient-to-l from-[#ffed28]/5 to-transparent rounded-full blur-3xl -translate-y-1/2 pointer-events-none" />
      
      <div className="relative z-10 w-full px-6 sm:px-8 lg:px-16 xl:px-24">
        <div className="max-w-5xl mx-auto">
          {/* Section Header */}
          <div ref={headerRef} className="text-center mb-16">
            <span className="reveal-item section-label inline-block mb-4">Testimoni</span>
            <h2 className="reveal-item text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Apa Kata <span className="text-gradient">Klien</span> Saya
            </h2>
            <p className="reveal-item text-gray-600 max-w-2xl mx-auto text-lg">
              Feedback dari klien yang telah bekerja sama dengan saya.
            </p>
          </div>

          {/* Testimonial Slider */}
          <div ref={sliderRef} className="relative">
            {/* Quote Icon */}
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 w-16 h-16 bg-[#ffed28] rounded-2xl flex items-center justify-center shadow-lg z-10">
              <Quote className="w-8 h-8" />
            </div>

            {/* Main Card */}
            <div className="testimonial-card bg-[#f8f8f8] rounded-3xl p-8 sm:p-12 pt-16 relative">
              {/* Rating */}
              <div className="flex justify-center gap-1 mb-6">
                {[...Array(currentTestimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-[#ffed28] text-[#ffed28]" />
                ))}
              </div>

              {/* Content */}
              <blockquote className="text-center mb-8">
                <p className="text-lg sm:text-xl lg:text-2xl text-gray-700 leading-relaxed italic">
                  "{currentTestimonial.content}"
                </p>
              </blockquote>

              {/* Author */}
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 rounded-full overflow-hidden border-4 border-white shadow-lg mb-4">
                  <img
                    src={currentTestimonial.image}
                    alt={currentTestimonial.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h4 className="text-lg font-bold">{currentTestimonial.name}</h4>
                <p className="text-gray-500 text-sm">
                  {currentTestimonial.role} di {currentTestimonial.company}
                </p>
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <button
                onClick={prevSlide}
                disabled={isAnimating}
                className="w-12 h-12 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-[#ffed28] transition-colors duration-300 disabled:opacity-50"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>

              {/* Dots */}
              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => goToSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentIndex 
                        ? 'w-8 bg-[#ffed28]' 
                        : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={nextSlide}
                disabled={isAnimating}
                className="w-12 h-12 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-[#ffed28] transition-colors duration-300 disabled:opacity-50"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Client Logos */}
          <div className="mt-20">
            <p className="text-center text-gray-500 text-sm mb-8">Dipercaya oleh berbagai perusahaan</p>
            <div className="flex flex-wrap justify-center items-center gap-8 opacity-50">
              {['TechStart', 'CreativeHub', 'InnovateCo', 'DigitalFirst', 'NextGen'].map((company, index) => (
                <div 
                  key={index}
                  className="text-xl font-bold text-gray-400 hover:text-gray-600 transition-colors cursor-default"
                >
                  {company}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
