import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Figma, 
  Code2, 
  Palette, 
  GitBranch, 
  Terminal,
  Cpu,
  Globe,
  Box,
  Sparkles
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface SkillCategory {
  title: string;
  icon: React.ElementType;
  skills: { name: string; level: number; icon?: React.ElementType }[];
}

const skillCategories: SkillCategory[] = [
  {
    title: 'Design',
    icon: Palette,
    skills: [
      { name: 'Figma', level: 95, icon: Figma },
      { name: 'Adobe XD', level: 90 },
      { name: 'Photoshop', level: 85 },
      { name: 'Illustrator', level: 80 },
      { name: 'Sketch', level: 75 }
    ]
  },
  {
    title: 'Development',
    icon: Code2,
    skills: [
      { name: 'HTML/CSS', level: 95, icon: Globe },
      { name: 'JavaScript', level: 90, icon: Terminal },
      { name: 'React', level: 88, icon: Code2 },
      { name: 'Node.js', level: 82, icon: Cpu },
      { name: 'Python', level: 75, icon: Terminal }
    ]
  },
  {
    title: 'Tools',
    icon: Box,
    skills: [
      { name: 'Git', level: 90, icon: GitBranch },
      { name: 'VS Code', level: 95, icon: Code2 },
      { name: 'Webpack', level: 80 },
      { name: 'Figma', level: 95, icon: Figma },
      { name: 'Jira', level: 85 }
    ]
  }
];

const additionalSkills = [
  'TypeScript', 'Next.js', 'Tailwind CSS', 'MongoDB', 'PostgreSQL', 
  'GraphQL', 'REST API', 'AWS', 'Docker', 'CI/CD'
];

const Skills = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const categoriesRef = useRef<HTMLDivElement>(null);
  const additionalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      const headerItems = headerRef.current?.querySelectorAll('.reveal-item');
      if (headerItems && headerItems.length > 0) {
        gsap.fromTo(headerItems,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Categories animation
      const categories = categoriesRef.current?.querySelectorAll('.skill-category');
      if (categories && categories.length > 0) {
        gsap.fromTo(categories,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.2,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: categoriesRef.current,
              start: 'top 70%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Skill bars animation
      const skillBars = sectionRef.current?.querySelectorAll('.skill-bar');
      if (skillBars) {
        skillBars.forEach((bar) => {
          const level = bar.getAttribute('data-level');
          gsap.fromTo(bar,
            { width: '0%' },
            {
              width: `${level}%`,
              duration: 1.5,
              ease: 'expo.out',
              scrollTrigger: {
                trigger: bar,
                start: 'top 85%',
                toggleActions: 'play none none reverse'
              }
            }
          );
        });
      }

      // Additional skills animation
      const additionalSkills = additionalRef.current?.querySelectorAll('.additional-skill');
      if (additionalSkills) {
        gsap.fromTo(additionalSkills,
          { opacity: 0, scale: 0.8 },
          {
            opacity: 1,
            scale: 1,
            duration: 0.4,
            stagger: 0.05,
            ease: 'back.out(1.7)',
            scrollTrigger: {
              trigger: additionalRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="keahlian"
      className="relative w-full py-24 lg:py-32 bg-[#f8f8f8] overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-white to-transparent" />
      
      <div className="relative z-10 w-full px-6 sm:px-8 lg:px-16 xl:px-24">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div ref={headerRef} className="text-center mb-16">
            <span className="reveal-item section-label inline-block mb-4">Keahlian</span>
            <h2 className="reveal-item text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Skillset <span className="text-gradient">Teknis</span> Saya
            </h2>
            <p className="reveal-item text-gray-600 max-w-2xl mx-auto text-lg">
              Kombinasi keahlian desain dan teknologi yang saya kuasai 
              untuk memberikan hasil terbaik.
            </p>
          </div>

          {/* Skills Categories */}
          <div ref={categoriesRef} className="grid lg:grid-cols-3 gap-8 mb-16">
            {skillCategories.map((category, categoryIndex) => (
              <div 
                key={categoryIndex}
                className="skill-category bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-500"
              >
                {/* Category Header */}
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-14 h-14 bg-[#ffed28] rounded-2xl flex items-center justify-center">
                    <category.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-bold">{category.title}</h3>
                </div>

                {/* Skills List */}
                <div className="space-y-5">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skillIndex} className="group">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {skill.icon && <skill.icon className="w-4 h-4 text-gray-400" />}
                          <span className="font-medium text-sm">{skill.name}</span>
                        </div>
                        <span className="text-sm text-gray-500">{skill.level}%</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="skill-bar h-full bg-gradient-to-r from-[#ffed28] to-[#ffc107] rounded-full transition-all duration-1000"
                          data-level={skill.level}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Additional Skills */}
          <div ref={additionalRef} className="bg-white rounded-3xl p-8 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <Sparkles className="w-6 h-6 text-[#ffed28]" />
              <h3 className="text-xl font-bold">Keahlian Tambahan</h3>
            </div>
            <div className="flex flex-wrap gap-3">
              {additionalSkills.map((skill, index) => (
                <span
                  key={index}
                  className="additional-skill px-5 py-2.5 bg-[#f8f8f8] rounded-full text-sm font-medium text-gray-700 hover:bg-[#ffed28] hover:text-black transition-all duration-300 hover:scale-105 cursor-default"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Experience Timeline */}
          <div className="mt-16">
            <h3 className="text-2xl font-bold text-center mb-10">Pengalaman Kerja</h3>
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gray-200 md:-translate-x-1/2" />
              
              {/* Timeline items */}
              {[
                {
                  year: '2023 - Sekarang',
                  title: 'Senior UI/UX Designer',
                  company: 'Tech Company',
                  description: 'Memimpin tim desain dan mengembangkan design system.'
                },
                {
                  year: '2021 - 2023',
                  title: 'Full-Stack Developer',
                  company: 'Digital Agency',
                  description: 'Mengembangkan aplikasi web dan mobile untuk berbagai klien.'
                },
                {
                  year: '2019 - 2021',
                  title: 'Junior Designer',
                  company: 'Startup Company',
                  description: 'Mendesain UI/UX untuk produk digital.'
                }
              ].map((item, index) => (
                <div 
                  key={index}
                  className={`relative flex items-start gap-8 mb-10 ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                >
                  {/* Content */}
                  <div className={`flex-1 ml-12 md:ml-0 ${
                    index % 2 === 0 ? 'md:text-right md:pr-12' : 'md:text-left md:pl-12'
                  }`}>
                    <span className="inline-block px-4 py-1 bg-[#ffed28] rounded-full text-sm font-medium mb-2">
                      {item.year}
                    </span>
                    <h4 className="text-lg font-bold">{item.title}</h4>
                    <p className="text-gray-500 text-sm mb-1">{item.company}</p>
                    <p className="text-gray-600 text-sm">{item.description}</p>
                  </div>
                  
                  {/* Dot */}
                  <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-[#ffed28] rounded-full border-4 border-white shadow-md md:-translate-x-1/2 mt-1" />
                  
                  {/* Empty space for alternating layout */}
                  <div className="hidden md:block flex-1" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
